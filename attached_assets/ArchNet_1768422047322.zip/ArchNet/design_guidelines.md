# Design Guidelines: Front-End Preservation Project

## Core Principle
**Preserve the existing Front-End exactly as-is. No visual changes, layout modifications, or component redesigns.**

## Design Approach
**Preservation-First**: Maintain all existing UI patterns, component structures, and visual treatments from the current v0.dev-generated interface.

## Design Constraints

### What to Preserve (100% Unchanged)
- All component layouts and structures
- Existing spacing and padding systems
- Current typography hierarchy and font choices
- All color schemes and visual treatments
- Existing animation patterns
- Current responsive breakpoints
- All styling implementations

### What to Modify (Code-Only)
- Remove v0.dev references and metadata
- Replace mock data with real API integration
- Implement proper state management for real data
- Add proper loading and error states
- Ensure auth-protected routing works correctly

## New Feature Guidelines (If Required)

If new components are added for Back-End integration:

**Typography**: Match existing font families, sizes, and weights
**Spacing**: Use the same Tailwind spacing units as existing components
**Components**: Follow established patterns from current UI library
**Forms**: Maintain consistency with existing form styling
**Feedback States**: Align loading spinners, error messages, and success states with current design language

## Images
Preserve all existing images and their placements. If new images are needed for authentication or user profiles, maintain the current image styling patterns (aspect ratios, border radius, shadows).

## Key Directive
Treat the existing Front-End as a design system reference. Any new elements must be indistinguishable from the original implementation.