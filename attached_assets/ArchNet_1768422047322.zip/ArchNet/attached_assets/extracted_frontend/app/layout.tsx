import type React from "react"
import { Inter, Playfair_Display } from "next/font/google"
import "./globals.css"
import { ComparePanel } from "@/components/compare-panel"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
})

export const metadata = {
  title: "ArchNet Jordan - Architectural Community Platform",
  description: "Gathering all architectural resources, competitions, books, and opportunities in Jordan",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="font-sans antialiased">
        {children}
        <ComparePanel />
      </body>
    </html>
  )
}
